import React from "react";
import "./VideoPlayerMock.css";
import math from "../../assets/IMG_3634 (2).mp4";
import geography from "../../assets/IMG_3670.mp4";
import history from "../../assets/IMG_3651.mp4";

interface VideoPlayerMockProps {
  subjectName: string;
  keyName: string;
  topicName: string;
}

const video = {
  math: math,
  geography: geography,
  history: history,
};

export const VideoPlayerMock: React.FC<VideoPlayerMockProps> = ({
  subjectName,
  topicName,
  keyName,
}) => {
  return (
    <div className="video-player-mock">
      <div className="video-header">
        <h3 className="video-subject">{subjectName}</h3>
        <p className="video-topic">{topicName}</p>
      </div>

      <div className="video-container">
        <div className="video-content">
          <div className="video-placeholder">
            <video
              autoPlay
              muted
              loop
              playsInline
              className="hero-video-bg"
              disablePictureInPicture
              controlsList="nodownload nofullscreen noremoteplayback"
            >
              <source
                src={video[keyName as keyof typeof video]}
                type="video/mp4"
              />
            </video>
          </div>
        </div>
      </div>
    </div>
  );
};
