import React from "react";
import { Link } from "react-router-dom";
import "./Footer.css";

export const Footer: React.FC = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-section">
          <h3>Mega School</h3>
          <p>Интерактивная платформа для обучения с ИИ-другом</p>
        </div>
        <div className="footer-section">
          <h4>Навигация</h4>
          <Link to="/dashboard">Личный кабинет</Link>
          <Link to="/rating">Рейтинг</Link>
        </div>
        <div className="footer-section">
          <h4>Регистрация</h4>
          <Link to="/auth/login">Войти</Link>
          <Link to="/auth/register">Регистрация</Link>
        </div>
      </div>
      <div className="footer-bottom">
        <p>&copy; 2026 EDU KIDS. Все права защищены нами :)</p>
      </div>
    </footer>
  );
};
